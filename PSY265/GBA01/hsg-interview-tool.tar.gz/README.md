# HSG Screening Interview Tool — PSY265 GBA01

A static, standalone page for typing in interview answers live, using the group's finalized
13-item question set (demographics + Attitude / Subjective Norms / Perceived Behavioural
Control / Final confirmation / Post question). No AI calls, no backend, no login — just a form
that autosaves to the browser as you type.

## Files

- `index.html` — the tool. Open it directly in a browser, or host it on GitHub Pages.
- `demographics.xlsx` — starter spreadsheet with columns Interviewee ID / Age / Gender / Race /
  Profession / Highest Education Status, one row per P1–P5.

## Using it during an interview

1. Open `index.html` (locally, or via your GitHub Pages URL — see below).
2. Pick the interviewee tab on the left (P1–P5, or add more).
3. Fill demographics, then type each answer as the interviewee gives it. It autosaves to that
   browser's local storage a moment after you stop typing (the "Saved hh:mm:ss" indicator top
   right confirms it).
4. Before you close the tab or switch devices, click **Export backup (.json)** — this downloads
   everything (all interviewees) as one file you can re-import later with **Import backup**.
   Browser local storage is per-browser, per-device: it does NOT sync across devices and can be
   cleared, so the JSON export is your real backup, not the autosave alone.
5. **Export demographics table (.csv)** gives you the age/gender/race/profession/education table
   for all interviewees in one file, ready to paste into your slide deck.
6. **Export this interview (.md)** gives you a readable transcript of one interviewee's full
   Q&A, for your write-up.

## Hosting on GitHub Pages

```
gh repo create hsg-interview-tool --public --source=. --push
# then in the repo settings: Settings -> Pages -> Deploy from branch -> main -> /(root)
```

It'll be reachable at `https://<you>.github.io/hsg-interview-tool/`. Since it holds no
credentials or server calls, a public repo is fine — just don't commit a JSON backup file with
real interview data into a public repo; keep exported backups local.

## GenAI disclosure note (per the GBA01 brief)

The question set itself was refined with AI-assisted brainstorming earlier in drafting (per the
brief's permitted "brainstorming ideas/outlines with disclosure") — disclose that per your
assignment's format. This tool itself is a plain static form with no AI in it.
